package com.socgen.bsc.dpc.jobmon.entries

import io.circe._
import io.circe.generic.semiauto._


/** Register useful information about a Spark application. */
case class AppEntry(var appName: String,
                    var appId: String,
                    var appStartTime: Long,
                    var appSparkStartTime: Long = -1,
                    var appEndTime: Long = -1,
                    var appRecordsRead: Long = 0,
                    var appRecordsWritten: Long = 0,
                    var appExecutorRunTime: Long = 0,
                    var appExecutorCpuTime: Long = 0,
                    var failedStage: Int = 0)

