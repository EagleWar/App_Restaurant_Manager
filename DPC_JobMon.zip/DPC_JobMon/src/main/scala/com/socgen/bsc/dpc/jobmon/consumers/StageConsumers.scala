package com.socgen.bsc.dpc.jobmon.consumers

import com.socgen.bsc.dpc.jobmon.JobMon
import com.socgen.bsc.dpc.jobmon.entries.JobEntry
import org.apache.spark.scheduler.SparkListenerStageCompleted

//region Trait

trait StageConsumer
{
    val name: String

    def triggerOn(jobEntry: JobEntry, stageCompleted: SparkListenerStageCompleted): Unit
}

//endregion

//region Consumer definition

class TimeRecorder extends StageConsumer
{
    val name = "TimeRecorder"

    override def triggerOn(jobEntry: JobEntry, stageCompleted: SparkListenerStageCompleted): Unit =
    {
        // Fetching time metrics
        val stageId = stageCompleted.stageInfo.stageId
        val stageRunTime = stageCompleted.stageInfo.taskMetrics.executorRunTime
        val stageCpuTime = stageCompleted.stageInfo.taskMetrics.executorCpuTime

        // Saving information on linked job entry
        jobEntry.executorRunTime += (stageId -> stageRunTime)
        jobEntry.executorCpuTime += (stageId -> stageCpuTime)

        // Sending back to main object
        JobMon.addOrUpdateJobEntry(jobEntry)
    }
}

// TODO : Add more consumers as needed

//endregion