package com.socgen.bsc.dpc.jobmon

import java.text.SimpleDateFormat

import com.socgen.bsc.dpc.jobmon.consumers._
import com.socgen.bsc.dpc.jobmon.consumers.collections._
import com.socgen.bsc.dpc.jobmon.entries.{AppEntry, JobEntry, QueryEntry}
import io.circe._
import org.apache.spark.SparkConf
import scalaj.http._

import scala.collection.mutable.{Buffer => Buff, Map => MMap, Set => MSet}


/** Companion object to emulate static behavior in Scala. */
object JobMon
{
    //region Attributes

    // Monitoring attributes
    protected[jobmon] val jobEntries: MMap[Int, JobEntry] = MMap[Int, JobEntry]()
    protected[jobmon] val queryEntries: MMap[Long, QueryEntry] = MMap[Long, QueryEntry]()
    protected[jobmon] var appEntry: AppEntry = AppEntry("undefined", "unknown", System.currentTimeMillis())

    // Elastic Search configuration
    case class EsConfig(nodesUri: String, port: Int, defaultTopic: String, credentials: (String, String))

    // Used for execution workflow
    private val stageToJobId: MMap[Int, Int] = MMap[Int, Int]()
    private var artifactPrefixPath: Option[String] = None
    private var esConfig: Option[EsConfig] = None

    // Consumers shared across listener classes
    protected[jobmon] val activeCollections: MSet[Collection] = MSet(CoreCollection)
    protected[jobmon] val taskConsumers: Buff[TaskConsumer] = Buff(new RecordsCounter)
    protected[jobmon] val stageConsumers: Buff[StageConsumer] = Buff(new TimeRecorder)
    protected[jobmon] val jobConsumers: Buff[JobConsumer] = Buff(new JobEntryFiller)
    protected[jobmon] val queryConsumers: Buff[QueryConsumer] = Buff(new QueryEntryFiller, new SavedTableFiller)
    protected[jobmon] val appConsumers: Buff[AppConsumer] = Buff(new AppEntryFiller)

    //endregion

    //region Protected functions

    // Getter/Setter pattern (scala passes args by copy)

    protected[jobmon] def setStageToJobId(stageId: Int, jobId: Int): Unit =
        this.stageToJobId(stageId) = jobId

    protected[jobmon] def getEntryFromJobId(jobId: Int): Option[JobEntry] =
        this.jobEntries.get(jobId)

    protected[jobmon] def getEntryFromStageId(stageId: Int): Option[JobEntry] =
        this.jobEntries.get(this.stageToJobId.getOrElse(stageId, -1))

    protected[jobmon] def getJobEntries: MMap[Int, JobEntry] =
        this.jobEntries

    protected[jobmon] def getJobEntriesFromQuery(queryEntry: QueryEntry): Seq[JobEntry] =
        queryEntry.relatedJobIds.map(this.jobEntries(_))

    protected[jobmon] def addOrUpdateJobEntry(jobEntry: JobEntry): Unit =
        this.jobEntries(jobEntry.jobId) = jobEntry

    protected[jobmon] def getAppEntry: AppEntry =
        this.appEntry

    protected[jobmon] def updateAppEntry(appEntry: AppEntry): Unit =
        this.appEntry = appEntry

    protected[jobmon] def getQueryEntry(queryId: Long): Option[QueryEntry] =
        this.queryEntries.get(queryId)

    protected[jobmon] def getQueryEntryFromNodeName(nodeName: String): Option[QueryEntry] =
        this.queryEntries.values.filter(_.queryExecution.executedPlan.nodeName == nodeName) match
        {
            case Seq(entry)    => Some(entry)
            case Seq()         => println(s"[JOBMON][QUERY][KO] Node name $nodeName not found in query map."); None;
            case Seq(first, _) => println(s"[JOBMON][QUERY][WARN] Multiple $nodeName found in query map."); Some(first);
        }

    protected[jobmon] def addOrUpdateQueryEntry(queryEntry: QueryEntry): Unit =
        this.queryEntries(queryEntry.executionId) = queryEntry

    protected[jobmon] def getArtifactPrefixPath: String =
    {
        assert(artifactPrefixPath.isDefined,
               "[JOBMON][ELASTIC][KO] NO ARTIFACT PATH HAS BEEN GIVEN !\n"
                   + " ~ Please call JobMon.setArtifactPrefixPath before creating the Spark Session.")

        this.artifactPrefixPath.get
            .concat(s"/${formatDayOf(appEntry.appStartTime)}/${appEntry.appName}_${appEntry.appId}/")
    }

    protected[jobmon] def sendJsontoEs(json: Json, path: String, topic: Option[String] = None): HttpResponse[String] =
    {
        assert(esConfig.isDefined,
               "[JOBMON][ELASTIC][KO] NO CONFIGURATION FOR ELASTIC HAS BEEN GIVEN !\n"
                   + " ~ Please call JobMon.configureES before creating the Spark Session.")

        val config = esConfig.get
        val response =
            Http(s"https://${config.nodesUri}:${config.port}/${topic.getOrElse(config.defaultTopic)}/"
                     + s"${formatDayOf(appEntry.appStartTime)}/${appEntry.appName}/${appEntry.appId}/$path")
            .auth(config.credentials._1, config.credentials._2)
            .header("Content-Type", "application/json")
            .header("Charset", "UTF-8")
            .postData(json.toString)
            .asString

        println("[JOBMON][ELK][REMOVEME] Printing HTTP response :\n ~ "
                    + response)

        response
    }


    //endregion

    //region Configuration functions

    // Call this JUST AFTER creating Spark Context
    def registerListeners(sparkConf: SparkConf): SparkConf =
    {
        // Registering inner listener classes
        val listenersToRegister = Seq("EntryCreator", "ConsumerManager", "QueryManager", "EntrySender")
                                  .map(classname => s"${this.getClass.getPackage.getName}.listeners.$classname")
                                  .mkString(",")

        sparkConf
        .set("spark.extraListeners", listenersToRegister)
    }

    // Tell JobMon where to save his artifacts
    def setArtifactPrefixPath(path: String): Unit =
        this.artifactPrefixPath = Some(path)

    // Configure a Elastic Search cluster connection
    def configureEsConnection(esNodesUri: String = "dhadlx140.dns21.socgen",
                              esPort: Int = 9200,
                              defaultTopic: String = "bscdpchprd-jobmon",
                              credentials: (String, String)): Unit =
        this.esConfig = Some(EsConfig(esNodesUri, esPort, defaultTopic, credentials))

    // Enables a consumer collection depending on user needs
    def enableCollection(collection: Collection): Boolean =
    {
        if (activeCollections.contains(collection))
        {
            println(s"[JOBMON][WARN] Collection ${collection.getClass.toString} has already been enabled.")
            return false
        }

        activeCollections += collection
        appConsumers ++= collection.appConsumers
        queryConsumers ++= collection.queryConsumers
        jobConsumers ++= collection.jobConsumers
        stageConsumers ++= collection.stageConsumers
        taskConsumers ++= collection.taskConsumers
        true
    }

    //endregion

    //region Helper functions

    def formatDayOf(time: Long): String =
        new SimpleDateFormat("dd-MM-yyyy").format(time)

    //endregion
}


