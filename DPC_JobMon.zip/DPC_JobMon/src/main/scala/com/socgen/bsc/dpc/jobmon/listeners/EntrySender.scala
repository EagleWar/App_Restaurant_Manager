package com.socgen.bsc.dpc.jobmon.listeners

import com.socgen.bsc.dpc.jobmon.JobMon
import org.apache.spark.scheduler.{SparkListener, SparkListenerApplicationEnd, SparkListenerApplicationStart, SparkListenerJobEnd}

import java.text.SimpleDateFormat

/** Writes reports when a Job or the application ends */
class EntrySender extends SparkListener
{

    def formatLongTime(time: Long): String =
    {
        new SimpleDateFormat("HH:mm:ss").format(time)
    }

    override def onApplicationStart(appStart: SparkListenerApplicationStart): Unit =
    {
        // Filling app entry
        val appEntry = JobMon.getAppEntry
        appEntry.appName = appStart.appName
        appEntry.appId = appStart.appId.getOrElse("unknown")
        appEntry.appSparkStartTime = appStart.time

        // Sending back to main object
        JobMon.updateAppEntry(appEntry)
    }

    override def onJobEnd(jobEnd: SparkListenerJobEnd): Unit =
    {
        // Fetching linked JobEntry.
        JobMon.getEntryFromJobId(jobEnd.jobId) match
        {
            case Some(entry) => JobMon.jobConsumers.foreach(_.triggerOn(entry, jobEnd))
            case None        => println(s"[JOBMON][JOB][KO] ID ${jobEnd.jobId} not registered in maps.")
        }
    }

    override def onApplicationEnd(appEnd: SparkListenerApplicationEnd): Unit =
    {
        JobMon.appConsumers.foreach(_.triggerOn(JobMon.getAppEntry, JobMon.getJobEntries, appEnd))
    }
}
