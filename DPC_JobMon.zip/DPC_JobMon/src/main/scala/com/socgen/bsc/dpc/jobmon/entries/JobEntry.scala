package com.socgen.bsc.dpc.jobmon.entries

import scala.collection.mutable.{Map => MMap}
import org.apache.spark.scheduler.JobResult


/** Register useful informations about a Spark job. */
case class JobEntry(
    // Job related info
    val jobId: Int,
    val queryExecutionId: Long,
    val startTime: Long,
    var endTime: Long = -1,
    var jobResult: Option[JobResult] = None,

    // Task related info (map key is task ID)
    var recordsRead: MMap[Long, Long] = MMap[Long, Long](),
    var recordsWritten: MMap[Long, Long] = MMap[Long, Long](),
    var totalRecordsRead: Long = 0,
    var totalRecordsWritten: Long = 0,

    // Stage related info (map key is stage ID)
    val executorRunTime: MMap[Int, Long] = MMap[Int, Long](),
    val executorCpuTime: MMap[Int, Long] = MMap[Int, Long](),
    var totalExecutorRunTime: Long = 0,
    var totalExecutorCpuTime: Long = 0,
    var failedStage: Int = 0)


