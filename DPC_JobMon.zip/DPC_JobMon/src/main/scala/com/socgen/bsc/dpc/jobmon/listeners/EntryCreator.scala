package com.socgen.bsc.dpc.jobmon.listeners

import com.socgen.bsc.dpc.jobmon.JobMon
import com.socgen.bsc.dpc.jobmon.entries.JobEntry
import org.apache.spark.scheduler.{SparkListener, SparkListenerJobStart}

/** Creates a JobEntry object when a new Spark job starts, and registers it. */
class EntryCreator extends SparkListener
{
    private val SQL_EXECUTION_ID_KEY = "spark.sql.execution.id"

    override def onJobStart(jobStart: SparkListenerJobStart): Unit =
    {
        // Taken from Spark WebUI source code : Don't ask.
        // src/main/scala/org/apache/spark/status/AppStatusListener.scala
        val queryExecutionId: Long = Option(jobStart.properties)
                                     .flatMap(p => Option(p.getProperty(SQL_EXECUTION_ID_KEY))
                                                   .map(_.toLong))
                                     .getOrElse(-1)

        // Referencing Job to related query if it exists
        if (queryExecutionId != -1)
        {
            val relatedQuery = JobMon.getQueryEntry(queryExecutionId).get
            relatedQuery.relatedJobIds += jobStart.jobId
            JobMon.addOrUpdateQueryEntry(relatedQuery)
        }

        // Creating and registering jobEntry instance
        JobMon.addOrUpdateJobEntry(JobEntry(jobStart.jobId, queryExecutionId, jobStart.time))

        // Filling ID map to register stage ID.
        jobStart.stageIds.foreach(JobMon.setStageToJobId(_, jobStart.jobId))
    }
}
