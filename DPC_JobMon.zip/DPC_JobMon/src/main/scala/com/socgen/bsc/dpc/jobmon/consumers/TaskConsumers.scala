package com.socgen.bsc.dpc.jobmon.consumers

import com.socgen.bsc.dpc.jobmon.JobMon
import com.socgen.bsc.dpc.jobmon.entries.JobEntry
import org.apache.spark.scheduler.SparkListenerTaskEnd

//region Trait

trait TaskConsumer
{
    val name: String

    def triggerOn(jobEntry: JobEntry, taskCompleted: SparkListenerTaskEnd): Unit
}

//endregion

//region Consumer definition

class RecordsCounter extends TaskConsumer
{
    val name = "RecordsCounter"

    override def triggerOn(jobEntry: JobEntry, taskCompleted: SparkListenerTaskEnd): Unit =
    {
        // Fetching input/output metrics
        val taskId: Long = taskCompleted.taskInfo.taskId
        val taskRead = taskCompleted.taskMetrics.inputMetrics.recordsRead
        val taskWritten = taskCompleted.taskMetrics.outputMetrics.recordsWritten

        // Saving information on linked job entry
        jobEntry.recordsRead += (taskId -> taskRead)
        jobEntry.recordsWritten += (taskId -> taskWritten)

        // Sending back to main object
        JobMon.addOrUpdateJobEntry(jobEntry)
    }
}

// TODO : Add more consumers as needed

//endregion



