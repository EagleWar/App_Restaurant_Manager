package com.socgen.bsc.dpc.jobmon.listeners

import com.socgen.bsc.dpc.jobmon.JobMon
import org.apache.spark.scheduler.{SparkListener, SparkListenerStageCompleted, SparkListenerTaskEnd}


/** Calls specific consumer instance in linked JobEntry when a listener triggers */
class ConsumerManager extends SparkListener
{

    override def onTaskEnd(taskEnd: SparkListenerTaskEnd): Unit =
    {
        JobMon.getEntryFromStageId(taskEnd.stageId) match
        {
            case Some(entry) => JobMon.taskConsumers.foreach(_.triggerOn(entry, taskEnd))
            case None        => println(s"[JOBMON][TASK][KO] ID ${taskEnd.taskInfo.taskId} not registered in maps.")
        }
    }

    override def onStageCompleted(stageEnd: SparkListenerStageCompleted): Unit =
    {
        JobMon.getEntryFromStageId(stageEnd.stageInfo.stageId) match
        {
            case Some(entry) => JobMon.stageConsumers.foreach(_.triggerOn(entry, stageEnd))
            case None        => println(s"[JOBMON][STAGE][KO] ID ${stageEnd.stageInfo.stageId} not registered in maps.")
        }
    }
}

