package com.socgen.bsc.dpc.jobmon.entries

import org.apache.spark.sql.execution.{QueryExecution, SparkPlanInfo}


import scala.collection.mutable.{Buffer => Buff}

/** Register useful information about a Spark Query. */
case class QueryEntry(
    // Query related info
    val executionId: Long,
    var queryExecution: QueryExecution,
    val startTime: Long,

    //  Info gotten from SQL START spark listener
    val sparkPlanInfo: SparkPlanInfo,
    val details: String,
    val description: String,
    val physicalPlanDescription: String,

    // Related job infos
    var relatedJobIds: Buff[Int] = Buff[Int](),
    var recordsRead: Long = 0,
    var recordsWritten: Long = 0,
    var executorRunTime: Long = 0,
    var executorCpuTime: Long = 0,

    // Metrics gotten from DriverAccumUpdatesM
    var metrics: Seq[(Long, Long)] = Seq[(Long, Long)](),

    // Used only for queries that saves tables
    var savedTable: Option[QueryEntry.SavedTable] = None,

    // Info gotten from SQL END spark listener
    var endTime: Long = -1,
    var querySuccess: Option[Boolean] = None,
    var queryFailReason: Option[String] = None
)

// Companion object to define inner class
object QueryEntry
{

    case class SavedTable(
        tableName: String,
        database: String,
        tableType: String,
        locationUri: String,
        compressed: String,
        provider: String,
        mode: String,
        outputColumnNames: String,
        numPartitions: String)

}


