package com.socgen.bsc.dpc.jobmon.consumers

import java.text.SimpleDateFormat

import com.socgen.bsc.dpc.jobmon.JobMon
import com.socgen.bsc.dpc.jobmon.entries.{AppEntry, JobEntry, Jsonify}
import io.circe.syntax._
import org.apache.spark.scheduler.SparkListenerApplicationEnd
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FSDataOutputStream, FileSystem, Path}
import org.apache.spark.sql.SparkSession
import org.elasticsearch.spark.sql._

import scala.collection.mutable.{Map => MMap}


//region Trait

trait AppConsumer
{
    val name: String

    def triggerOn(appEntry: AppEntry, jobEntries: MMap[Int, JobEntry], appEnd: SparkListenerApplicationEnd): Unit
}

//endregion

//region Consumer definition

class AppEntryFiller extends AppConsumer
{
    val name = "AppEntryFiller"

    override def triggerOn(appEntry: AppEntry, jobEntries: MMap[Int, JobEntry],
                           appEnd: SparkListenerApplicationEnd): Unit =
    {
        // Filling app entry
        appEntry.appEndTime = appEnd.time
        appEntry.appRecordsRead = jobEntries.values.map(_.totalRecordsRead).sum
        appEntry.appRecordsWritten = jobEntries.values.map(_.totalRecordsWritten).sum
        appEntry.appExecutorRunTime = jobEntries.values.map(_.totalExecutorRunTime).sum
        appEntry.appExecutorCpuTime = jobEntries.values.map(_.totalExecutorCpuTime).sum
        appEntry.failedStage = jobEntries.values.map(_.failedStage).sum

        // Sending back to main object
        JobMon.updateAppEntry(appEntry)
    }
}

class TinyAppPrinter extends AppConsumer
{
    val name = "TinyAppPrinter"

    def formatLongTime(time: Long): String =
        new SimpleDateFormat("HH:mm:ss").format(time)

    override def triggerOn(appEntry: AppEntry, jobEntries: MMap[Int, JobEntry],
                           appEnd: SparkListenerApplicationEnd): Unit =
    {
        println(s"[JOBMON][APP] Application ${appEntry.appName} ended at ${formatLongTime(appEntry.appEndTime)}.\n"
                    + s" ~ Records read/written : ${appEntry.appRecordsRead} / ${appEntry.appRecordsWritten}.\n"
                    + s" ~ Absolute time taken : (Code) ${appEntry.appEndTime - appEntry.appStartTime} ms; (Spark) ${appEntry.appEndTime - appEntry.appSparkStartTime} ms.\n"
                    + s" ~ Executor run time : ${appEntry.appExecutorRunTime} ms; Executor cpu time : ${appEntry.appExecutorCpuTime} ns.")
    }
}


class JsonAppPrinter extends AppConsumer
{
    val name = "JsonAppPrinter"

    override def triggerOn(appEntry: AppEntry, jobEntries: MMap[Int, JobEntry],
                           appEnd: SparkListenerApplicationEnd): Unit =
    {
        import Jsonify.appEntryEncoder
        println(s"[JOBMON][APP] Writing app json :\n${appEntry.asJson}")
    }
}


class JsonAppLogger extends AppConsumer
{
    val name = "AppSummaryLogger"


    override def triggerOn(appEntry: AppEntry, jobEntries: MMap[Int, JobEntry],
                           appEnd: SparkListenerApplicationEnd): Unit =
    {
        import Jsonify.{appEntryEncoder, jobEntryEncoder}

        // Path creation
        val logPrefixPath = JobMon.getArtifactPrefixPath
        println(s"[JOBMON][APP] Trying to write jsons to $logPrefixPath.")

        val fs = FileSystem.get(new Configuration())

        // Writing app to json file
        val appOs: FSDataOutputStream = fs.create(new Path(s"$logPrefixPath/summary.json"))
        appOs.write(appEntry.asJson.toString.getBytes)
        appOs.close()

        // Writing jobs to json file
        val jobsOs: FSDataOutputStream = fs.create(new Path(s"$logPrefixPath/jobs.json"))
        jobsOs.write(jobEntries.toMap.asJson.toString.getBytes)
        jobsOs.close()
    }
}

class AppSummaryPublisher extends AppConsumer
{
    val name = "AppSummaryPublisher"

    override def triggerOn(appEntry: AppEntry, jobEntries: MMap[Int, JobEntry],
                           appEnd: SparkListenerApplicationEnd): Unit =
    {
        import Jsonify.appEntryEncoder
        JobMon.sendJsontoEs(appEntry.asJson, "entries/app")
    }
}

// TODO : Add more consumers as needed

//endregion