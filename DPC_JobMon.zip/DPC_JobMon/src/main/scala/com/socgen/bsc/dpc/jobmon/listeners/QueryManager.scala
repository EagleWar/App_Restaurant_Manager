package com.socgen.bsc.dpc.jobmon.listeners

import com.socgen.bsc.dpc.jobmon.JobMon
import com.socgen.bsc.dpc.jobmon.entries.QueryEntry
import org.apache.spark.scheduler.{SparkListener, SparkListenerEvent}
import org.apache.spark.sql.execution.QueryExecution
import org.apache.spark.sql.execution.ui.{SparkListenerDriverAccumUpdates, SparkListenerSQLExecutionEnd, SparkListenerSQLExecutionStart}
import org.apache.spark.sql.util.QueryExecutionListener

class QueryManager extends SparkListener with QueryExecutionListener
{
    override def onOtherEvent(event: SparkListenerEvent): Unit = event match
    {
        case e: SparkListenerSQLExecutionStart  => onExecutionStart(e)
        case e: SparkListenerSQLExecutionEnd    => onExecutionEnd(e)
        case e: SparkListenerDriverAccumUpdates => onDriverAccumUpdates(e)
        case _                                  => // Ignore
    }

    def onExecutionStart(event: SparkListenerSQLExecutionStart): Unit =
    {
        // Fetching related query information
        import org.apache.spark.sql.execution.SQLExecution
        val qe: QueryExecution = SQLExecution.getQueryExecution(event.executionId)

        // Creating query case class instance
        val queryEntry = QueryEntry(event.executionId, qe, event.time,
                                    event.sparkPlanInfo, event.details, event.description,
                                    event.physicalPlanDescription)

        // Sending to JobMon object
        JobMon.addOrUpdateQueryEntry(queryEntry)
    }

    def onDriverAccumUpdates(event: SparkListenerDriverAccumUpdates): Unit =
    {
        val queryEntry = JobMon.getQueryEntry(event.executionId).get
        queryEntry.metrics = event.accumUpdates
        JobMon.addOrUpdateQueryEntry(queryEntry)
    }


    def onExecutionEnd(event: SparkListenerSQLExecutionEnd): Unit =
    {
        // Fetching linked QueryEntry.
        JobMon.getQueryEntry(event.executionId) match
        {
            case Some(entry) => JobMon.queryConsumers.foreach(_.triggerOn(entry, event))
            case None        => println(s"[JOBMON][QUERY][KO] ID ${event.executionId} not registered in maps")
        }
    }


    override def onSuccess(funcName: String, qe: QueryExecution, durationNs: Long): Unit =
    {
        /* FIXME : Find a bridge between this QueryExecution and the one in related QueryEntry
        JobMon.getQueryEntryFromNodeName(qe.executedPlan.nodeName) match
        {
            case Some(entry) => // Found query
                entry.queryExecution = qe
                entry.querySuccess = Some(true)
                JobMon.addOrUpdateQueryEntry(entry)
                println(s"[JOBMON][REMOVEME] Query #${entry.executionId} updated !")
            case None        => // Ignore
        }
        */
    }

    override def onFailure(funcName: String, qe: QueryExecution, exception: Exception): Unit =
    {
        /* FIXME : Find a bridge between this QueryExecution and the one in related QueryEntry
        JobMon.getQueryEntryFromNodeName(qe.executedPlan.nodeName) match
        {
            case Some(entry) => // Found query
                entry.queryExecution = qe
                entry.querySuccess = Some(false)
                entry.queryFailReason = Some(exception.toString)
                JobMon.addOrUpdateQueryEntry(entry)
            case None        => // Ignore
        }
        */
    }
}

