package com.socgen.bsc.dpc.jobmon.entries

import com.socgen.bsc.dpc.jobmon.entries.QueryEntry.SavedTable
import io.circe._
import io.circe.generic.semiauto._
import io.circe.syntax._

object Jsonify
{
    // App entry
    implicit val appEntryEncoder: Encoder[AppEntry] = deriveEncoder

    // Job entry
    implicit val jobEntryEncoder: Encoder[JobEntry] =
        Encoder.forProduct14(
            "jobId", "queryExecutionId", "startTime", "endTime", "jobResult",
            "recordsRead", "recordsWritten", "totalRecordsRead", "totalRecordsWritten",
            "executorRunTime", "executorCpuTime", "totalExecutorRunTime", "totalExecutorCpuTime",
            "failedStage"
            )(je => (
            je.jobId, je.queryExecutionId, je.startTime, je.endTime, je.jobResult.getOrElse("<Unknown>").toString,
            je.recordsRead.toMap, je.recordsWritten.toMap, je.totalRecordsRead, je.totalRecordsWritten,
            je.executorRunTime.toMap, je.executorCpuTime.toMap, je.totalExecutorRunTime, je.totalExecutorCpuTime,
            je.failedStage))

    // Query entry

    // Inner class is trivial
    implicit val saveTableEncoder: Encoder[QueryEntry.SavedTable] = deriveEncoder
    // Outer class is not
    implicit val queryEntryEncoder: Encoder[QueryEntry] =
    {
        Encoder.forProduct18(
            // Query related info
            "executionId", "queryExecution", "startTime",
            //  Info gotten from SQL START spark listener
            "sparkPlanInfo", "details", "description", "physicalPlanDescription",
            // Related job infos
            "relatedJobIds", "recordsRead", "recordsWritten", "executorRunTime", "executorCpuTime",
            // Metrics gotten from DriverAccumUpdatesM
            "metrics",
            // Used only for queries that saves tables
            "isSavedTable", "savedTable",
            // Info gotten from SQL END spark listener
            "endTime", "querySuccess", "queryFailReason"
            )(qe => (
            // Query related info
            qe.executionId, qe.queryExecution.executedPlan.toJSON, qe.startTime,
            //  Info gotten from SQL START spark listener
            qe.sparkPlanInfo.nodeName, qe.details, qe.description, qe.physicalPlanDescription,
            // Related job infos
            qe.relatedJobIds, qe.recordsRead, qe.recordsWritten, qe.executorRunTime, qe.executorCpuTime,
            // Metrics gotten from DriverAccumUpdatesM
            qe.metrics,
            // Used only for queries that saves tables
            qe.savedTable.isDefined, qe.savedTable.map(_.asJson).getOrElse(Json.Null),
            // Info gotten from SQL END spark listener
            qe.endTime, qe.querySuccess.map(_.toString).getOrElse("<Unknown>"),
            qe.queryFailReason.map(_.asJson).getOrElse(Json.Null)))
    }
}

